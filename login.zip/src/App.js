import {Route, Routes, Navigate } from "react-router-dom";
import Main from "./components/Main";
import Signup from "./components/Singup";
import Login from "./components/Login";

// import ProductUpdate from "./Redux/ProductUpdate";
// import Productpage from "./Redux/Product";
// import { Provider,store } from "./Redux/mockStore";


function App() {
	const user = localStorage.getItem("token");





	return (


		<Routes>
			{user && <Route path="/" exact element={<Main />} />}
			<Route path="/signup" exact element={<Signup />} />
			<Route path="/login" exact element={<Login />} />
			<Route path="/" element={<Navigate replace to="/login" />} />
		</Routes>





// {/* <Provider store={store}>
// <ProductUpdate/>
// <Productpage/>
// </Provider> */}
			);
}

export default App;
